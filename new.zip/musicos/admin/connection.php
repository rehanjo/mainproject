<?php
$conn = mysqli_connect("localhost","root","","musicos");

// if($conn)
// {
// 	echo "Connection Successful hvjhvjhv";
// }
// else
// {
// 	echo "Connection not Successful";
// }
?>

